import { createAction } from '@reduxjs/toolkit';
export const addItem = createAction('cart/addItem');
export const removeItem = createAction('cart/removeItem');
